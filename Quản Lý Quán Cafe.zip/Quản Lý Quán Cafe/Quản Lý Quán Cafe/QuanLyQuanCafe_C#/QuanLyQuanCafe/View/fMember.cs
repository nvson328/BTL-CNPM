﻿using QuanLyQuanCafe.Controller;
using QuanLyQuanCafe.DAO;
using QuanLyQuanCafe.DTO;
using QuanLyQuanCafe.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.View
{
    public partial class fMember : Form
    {
        BindingSource memberlist = new BindingSource();

        public fMember()
        {
            InitializeComponent();
            Load();
        }
        new void Load()
        {
            dtgvMember.DataSource = memberlist;
            LoadListMember();
            AddMemberBinding();
        }
        #region methods
        List<Member> SearchMemberByphone(int phone)
        {
            List<Member> listMember = MemberDAO.Instance.SearchMemberByphone(phone);
            return listMember;
        }

        void AddMemberBinding()
        {
            txbMemberName.DataBindings.Add(new Binding("Text", dtgvMember.DataSource, "Name", true, DataSourceUpdateMode.Never));
            txbMemberID.DataBindings.Add(new Binding("Text", dtgvMember.DataSource, "ID", true, DataSourceUpdateMode.Never));
            nmPhone.DataBindings.Add(new Binding("Value", dtgvMember.DataSource, "Phone", true, DataSourceUpdateMode.Never));
        }
        void LoadListMember()
        {
            memberlist.DataSource = MemberDAO.Instance.GetListMember();
        }
        #endregion



        #region events
        private void btnAddMember_Click(object sender, EventArgs e)
        {
            string name = txbMemberName.Text;
            int phone = (int)nmPhone.Value;

            if (MemberDAO.Instance.InsertMember(name, phone))
            {
                MessageBox.Show("Thêm thành viên thành công");
                LoadListMember();
                if (insertMember != null)
                    insertMember(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi thêm thành viên");
            }
        }
        private void btnDeleteMember_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txbMemberID.Text);

            if (MemberDAO.Instance.DeleteMember(id))
            {
                MessageBox.Show("Xóa thành viên thành công");
                LoadListMember();
                if (deleteMember != null)
                    deleteMember(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi xóa thành viên");
            }
        }
        private void btnEditMember_Click(object sender, EventArgs e)
        {
            string name = txbMemberName.Text;
            int phone = (int)nmPhone.Value;
            int id = Convert.ToInt32(txbMemberID.Text);

            if (MemberDAO.Instance.UpdateMember(id, name, phone))
            {
                MessageBox.Show("Sửa thành viên thành công");
                LoadListMember();
                if (updateMember != null)
                    updateMember(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Có lỗi khi sửa thành viên");
            }
        }
        private void btnShowMember_Click(object sender, EventArgs e)
        {
            LoadListMember();
        }

        private void btnSearchMember_Click(object sender, EventArgs e)
        {
            memberlist.DataSource = SearchMemberByphone((int)nmSearchMemberPhone.Value);
        }
        private event EventHandler insertMember;
        public event EventHandler InsertMember
        {
            add { insertMember += value; }
            remove { insertMember -= value; }
        }

        private event EventHandler deleteMember;
        public event EventHandler DeleteMember
        {
            add { deleteMember += value; }
            remove { deleteMember -= value; }
        }

        private event EventHandler updateMember;
        public event EventHandler UpdateMember
        {
            add { updateMember += value; }
            remove { updateMember -= value; }
        }




        #endregion

        
    }
}