﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCafe.Model
{
    class Member
    {
        public Member(int id, string name, int phone)
        {
            this.ID = id;
            this.Name = name;
            this.Phone = phone;
        }

        public Member(DataRow row)
        {
            this.ID = (int)row["id"];
            this.Name = row["name"].ToString();
            this.Phone = (int)row["phone"];
        }


        private int phone;
        public int ID
        {
            get { return iD; }
            set { iD = value; }
        }
        private int iD;
      
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        private string name;




    }
}
