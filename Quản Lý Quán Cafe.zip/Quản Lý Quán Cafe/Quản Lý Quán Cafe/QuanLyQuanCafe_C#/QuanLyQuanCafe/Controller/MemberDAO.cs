﻿using QuanLyQuanCafe.DAO;
using QuanLyQuanCafe.DTO;
using QuanLyQuanCafe.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCafe.Controller
{
    class MemberDAO
    {
        private static MemberDAO instance;

        public static MemberDAO Instance
        {
            get { if (instance == null) instance = new MemberDAO(); return MemberDAO.instance; }
            private set { MemberDAO.instance = value; }
        }

        private MemberDAO() { }

        public List<Member> GetListMember()
        {
            List<Member> list = new List<Member>();

            string query = "select * from Member";

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                Member member = new Member(item);
                list.Add(member);
            }

            return list;
        }

        public List<Member> SearchMemberByphone(int phone)
        {
            List<Member> list = new List<Member>();

            string query = string.Format("SELECT * FROM dbo.Member WHERE dbo.fuConvertToUnsign1(phone) LIKE N'%' + dbo.fuConvertToUnsign1(N'{0}') + '%'", phone);

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                Member member = new Member(item);
                list.Add(member);
            }

            return list;
        }
        public bool InsertMember(string name, int phone)
        {
            string query = string.Format("INSERT dbo.Member ( name, phone )VALUES  ( N'{0}', {1})", name,phone);
            int result = DataProvider.Instance.ExecuteNonQuery(query);
            return result > 0;
        }

        public bool UpdateMember(int idMember, string name, int phone)
        {
            string query = string.Format("UPDATE dbo.Member SET name = N'{0}', phone = {1} WHERE id = {2}", name, phone, idMember);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
        public bool DeleteMember(int idMember)
        {
            string query = string.Format("Delete dbo.Member where id = {0}", idMember);

            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
    }
}
